<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class SetClientIdResp extends Stub { } 