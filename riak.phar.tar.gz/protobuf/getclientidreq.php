<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class GetClientIdReq extends Stub { } 