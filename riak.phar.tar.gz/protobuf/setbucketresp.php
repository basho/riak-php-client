<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class SetBucketResp extends Stub { } 