<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class PingReq extends Stub { } 