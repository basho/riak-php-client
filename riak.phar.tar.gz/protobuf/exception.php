<?php
namespace Riak\ProtoBuf; class Exception extends \Riak\Exception { } 