<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class DelResp extends Stub { } 