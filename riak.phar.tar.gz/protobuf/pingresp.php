<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class PingResp extends Stub { }