<?php
namespace Riak\ProtoBuf; use Riak\Protobuf; class ListBucketsReq extends Stub { } 