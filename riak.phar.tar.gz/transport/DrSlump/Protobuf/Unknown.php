<?php
 namespace DrSlump\Protobuf; abstract class Unknown { public $tag = 0; public $data = null; } 