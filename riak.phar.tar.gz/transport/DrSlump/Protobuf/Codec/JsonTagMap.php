<?php
 namespace DrSlump\Protobuf\Codec; use DrSlump\Protobuf; class JsonTagMap extends Json implements Protobuf\CodecInterface { public function __construct() { $this->useTagNumberAsKey(true); } } 