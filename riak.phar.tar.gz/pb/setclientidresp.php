<?php
namespace Riak\PB; class SetClientIdResp extends Message { } 