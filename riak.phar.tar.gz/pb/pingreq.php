<?php
namespace Riak\PB; class PingReq extends Message { } 