<?php
namespace Riak\PB; class GetClientIdReq extends Message { } 