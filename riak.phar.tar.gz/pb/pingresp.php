<?php
namespace Riak\PB; class PingResp extends Message { } 