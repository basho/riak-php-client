<?php
namespace Riak\PB; class SetBucketResp extends Message { } 