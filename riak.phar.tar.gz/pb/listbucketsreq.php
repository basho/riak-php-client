<?php
namespace Riak\PB; class ListBucketsReq extends Message { } 