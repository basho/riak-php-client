<?php
namespace Riak\PB; class GetServerInfoReq extends Message { } 