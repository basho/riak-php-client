<?php
namespace Riak\PB; class DelResp extends Message { } 